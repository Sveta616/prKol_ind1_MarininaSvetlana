﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            Stack<string> s1 = new Stack<string>();
            List<string> m = new List<string>();

            string[] mas = textBox1.Text.Split(' ');
            int f;

            foreach (string a in mas)
            {
                if (int.TryParse(a.ToString(), out f))
                {
                    m.Add(a);
                }
                if (a == "(")
                {
                    s1.Push(a);
                }
                if (a == ")")
                {
                    while (s1.Count != 0 && s1.Peek() != "(")
                    {
                        m.Add(s1.Pop());
                    }
                    s1.Pop();
                }
                if (Zn(a) == true)
                {
                    while (s1.Count != 0 && P(s1.Peek()) >= P(a))
                    {
                        m.Add(s1.Pop());
                    }
                    s1.Push(a);
                }
            }
            while (s1.Count != 0)
            {
               m.Add(s1.Pop());
            }
            for (int i = 0; i < m.Count; i++)
            {
                textBox2.Text = textBox2.Text + m[i] + " ";
            }
        }
        static int P(string a)
        {
            if (a == "") return 3;
            else if (a == "*" || a == "/") return 2;
            else if (a == "+" || a == "-") return 1;
            else return 0;
        }
        static bool Zn(string z)
        {
            if (z == "+" || z == "-" || z == "*" || z == "/" || z == "^") return true;
            else return false;
        }
    }
}
